> README.md for code accompanying the paper "Partial Multi-Label Learning with Noisy Label Identification" 

# PML-NI

This repository is the official implementation of the PML-NI algorithm of the paper "Partial Multi-Label Learning with Noisy Label Identification" and technical details of this algorithm can be found in the paper. 

## Requirements

- MATLAB, version 2016b and higher.


